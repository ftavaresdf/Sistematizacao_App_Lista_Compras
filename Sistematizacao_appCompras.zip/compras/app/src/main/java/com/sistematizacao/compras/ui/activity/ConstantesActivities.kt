package com.sistematizacao.compras.ui.activity

const val CHAVE_PRODUTO_ID: String = "PRODUTO_ID"