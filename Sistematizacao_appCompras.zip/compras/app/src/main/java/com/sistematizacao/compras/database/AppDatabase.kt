package com.sistematizacao.compras.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.sistematizacao.compras.database.converter.Converters
import com.sistematizacao.compras.database.dao.ProdutoDao
import com.sistematizacao.compras.model.Produto


@Database(entities = [Produto::class], version = 1, exportSchema = true)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun produtoDao(): ProdutoDao

    companion object {
        fun instancia(context: Context) : AppDatabase {
            return Room.databaseBuilder(
                context,
                AppDatabase::class.java,
                ".db"
            ).allowMainThreadQueries()
                .build()
        }
    }
}